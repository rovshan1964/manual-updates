# -*- coding: utf-8 -*-
import os
import sys
import xbmc
import urllib


##General vars
__plugin__ = "xbMako"
__author__ = "mr. kav"
__url__ = "http://xbmako.googlecode.com"
__svn_url__ = "http://xbmako.googlecode.com/svn/trunk/plugins/video/xbMako/"
__credits__ = ""
__version__ = "0.0.450"
__XBMC_Revision__ = ""

def get_params():
    Debug( 'get_params', True)
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
                            
    return param


LIB_PATH = xbmc.translatePath( os.path.join( os.getcwd(), 'resources', 'lib' ) )
sys.path.append (LIB_PATH)

from utilities import *

##Call relevant plugin to list
if ( __name__ == "__main__" ):
    print sys.argv
    if ( not sys.argv[ 2 ] ):
        name = 'MAKO.CO.IL'
        url = 'http://www.mako.co.il/mako-vod-keshet'
    elif ( sys.argv[ 2 ] ):
        params=get_params()
        url= urllib.unquote_plus(params["url"])
        name= urllib.unquote_plus(params["name"])
    import xbmcplugin_mako as plugin
    plugin.Main(name, url)

##We're done
sys.modules.clear()
