#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib2, re, json
from _header import *

BASE_NAME_STARTV  = common.replaceHTMLCodes('STAR TV&emsp;')
BASE_URL_STARTV   = 'http://startv.kg/'

BASE_NAME  = 'ТВ'
BASE_LABEL = 'tv'

@plugin.route('/site/' + BASE_LABEL)
def tv_index():
    item_list = get_channels()
    kgontv_playlist(item_list)
    xbmc.executebuiltin('ActivateWindow(VideoPlaylist)')





#@plugin.cached()
def get_channels():
    items = []
    try:
        items = [{
            'title': BASE_NAME_STARTV + set_color('Europa Plus TV', 'bold'),
            'url' : BASE_URL_STARTV + 'hls/provider/provider_europe.m3u8',
            'icon': get_local_icon('onlinetv/europaplustv')
        },{
            'title': BASE_NAME_STARTV + set_color('Спорт 2'.decode('utf-8'), 'bold'),
            'url' : BASE_URL_STARTV + 'hls/provider/provider_sport.m3u8',
            'icon': get_local_icon('onlinetv/sport2')
        },{
            'title': BASE_NAME_STARTV + set_color('Наука 2.0'.decode('utf-8'), 'bold'),
            'url' : BASE_URL_STARTV + 'hls/provider/provider_nauka.m3u8',
            'icon': get_local_icon('onlinetv/nauka2.0')
        },{
            'title': BASE_NAME_STARTV + set_color('Nickelodeon', 'bold'),
            'url' : BASE_URL_STARTV + 'hls/provider/provider_nickelodeon.m3u8',
            'icon': get_local_icon('onlinetv/nickelodeon')
        },{
            'title': BASE_NAME_STARTV + set_color('ЕвроКино'.decode('utf-8'), 'bold'),
            'url' : BASE_URL_STARTV + 'hls/provider/provider_eurokino.m3u8',
            'icon': get_local_icon('onlinetv/eurokino')
        }]
    except: pass
    return items