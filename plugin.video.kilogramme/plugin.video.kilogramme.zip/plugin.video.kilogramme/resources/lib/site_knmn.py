#!/usr/bin/python
# -*- coding: utf-8 -*-
import re, json, urllib
from _header import *

try:
    from collections import OrderedDict
except ImportError:
    from ordereddict import OrderedDict


BASE_URL    = 'http://www.kinoman.kg/'
BASE_API_ML = BASE_URL + 'ws/cineMovieList.aspx'
BASE_NAME   = 'Kinoman'
BASE_LABEL  = 'knmn'
GA_CODE     = 'UA-42626016-1'
NK_CODE     = '2719'

def get_session():
    try:
        cache = plugin.get_storage(BASE_LABEL, TTL = 360)
        session = cache['sessionid']
    except:
        result = common.fetchPage({'link': BASE_URL})
        if result['status'] == 200:
            session = re.compile('jsondata\.SESSION_ID = "(.+?)";').findall(result['content'])[0]
            cache['sessionid'] = session
    return session

SESSIONID = ''#get_session()


@plugin.route('/site/' + BASE_LABEL)
def knmn_index():
    item_list = get_categories()
    items     = []
    
    
    items = [{
        'label'     : item['title'],
        'path'      : plugin.url_for('knmn_movies_by_genre', id = item['id']),
        'thumbnail' : item['icon'],
    } for item in item_list]

    items = [{
        'label': set_color('[ Поиск ]', 'dialog', True),
        'path' : plugin.url_for('knmn_search'),
        'icon' : get_local_icon('find')
    },{
        'label': set_color('Рекомендуемые', 'light', True),
        'path' : plugin.url_for('knmn_get_top')
    }] + items
    
    return items


@plugin.route('/site/' + BASE_LABEL + '/genre/<id>/page/<page>', name='knmn_movies_by_genre_pagination')
@plugin.route('/site/' + BASE_LABEL + '/genre/<id>',             name='knmn_movies_by_genre', options={'page': '1'})
def knmn_movies_by_genre(id, page = '1'):
    item_list = get_movieList(id, page)
    items     = []

    if len(item_list['items']) > 0:
        items = [{
            'label'     : item['title'],
            'path'      : plugin.url_for('knmn_movie', url = item['url']),
            'thumbnail' : item['icon'],
        } for item in item_list['items']]
    else:
        plugin.notify('Остались только сериалы', BASE_NAME, image=get_local_icon('noty_' + BASE_LABEL))
    
    if(item_list['pagination']):
        for item in item_list['pagination']:
            items.insert(0, {
                'label': item['label'],
                'path' : plugin.url_for('knmn_movies_by_genre_pagination', id = id, page = item['page']) if item['search'] == False else plugin.url_for('knmn_go_to_page', id = id, page = item['page']),
                'icon' : item['icon'],
            })
    
    if(page == '1'):
        return items
    else:
        return plugin.finish(items, update_listing=True)


@plugin.route('/site/' + BASE_LABEL + '/ontop')
def knmn_get_top():
    item_list = get_movieList(id, refType = 'ontop')
    items     = []

    if len(item_list['items']) > 0:
        items = [{
            'label'     : item['title'],
            'path'      : plugin.url_for('knmn_movie', url = item['url']),
            'thumbnail' : item['icon'],
        } for item in item_list['items']]
    else:
        plugin.notify('Что-то пошло не так :(', BASE_NAME, image=get_local_icon('noty_' + BASE_LABEL))
    
    return items
    


@plugin.route('/site/' + BASE_LABEL + '/movie/<url>')
def knmn_movie(url):
    item_list = get_movie(url)
    items = [{
        'label'      : item['title'],
        'path'       : item['url'],
        'thumbnail'  : item['icon'],
        #'info'       : item['info'],
        #'properties' : item['properties'],
        'is_playable': True
    } for item in item_list]
    
    return items


@plugin.route('/site/' + BASE_LABEL + '/to_page/<id>/<page>')
def knmn_go_to_page(id, page = '1'):
    search_page = common.getUserInputNumbers('Укажите страницу')
    if(search_page):
        page = search_page if (int(search_page) > 0) else '1'

        items = knmn_movies_by_genre(id, page)

        return plugin.finish(items, update_listing=True)
    else:
        plugin.redirect('plugin://'+plugin.id+'/site/' + BASE_LABEL + '/genre/' + str(id) + '/page/' + str(page))


@plugin.route('/site/' + BASE_LABEL + '/search')
def knmn_search():
    search_val = plugin.keyboard('', 'Что ищете?')
    if(search_val):
        item_list = get_search_results(str(search_val))
        items = []
        if item_list:
            items = [{
                'label'     : item['title'],
                'path'      : plugin.url_for('knmn_movie', url = item['url']),
                'thumbnail' : item['icon'],
            } for item in item_list]
        else:
            plugin.notify('Фильмы не найдены', BASE_NAME, image=get_local_icon('noty_' + BASE_LABEL))
        
        return items
    else:
        plugin.redirect('plugin://'+plugin.id+'/site/' + BASE_LABEL)




#method
def get_search_results(search_query):
    items = []
    
    try:
        result = common.fetchPage({'link': BASE_API_ML, 'post_data':{
            'ln'    : 'ru',
            'action': 'autocomplete',
            'term'  : search_query,
        }})
        
        if result['status'] == 200:
            data = json.loads( result['content'] )

            for movie in data:
                if (movie['pagePath'].find( '/serialy-online/' ) == -1) and (movie['pagePath'].find( '/licenzionnye/' ) == -1):#Сериалы и новости пока не нужны в выдаче
                    title = movie['label'].strip()
                    icon  = ''
                    href  = movie['pagePath'][1:].decode('unicode_escape').encode('ascii','ignore')
                    id    = movie['id']
                    xbmc.log(str(items))
                    items.append({'title':title, 'icon':icon, 'id':id, 'url':href})
    except: pass
    return items


#method
def get_categories():
    items = []
    
    try:
        kg_stats(BASE_URL, GA_CODE, NK_CODE)

        genres = OrderedDict([
            ('Драмы', '3'),
            ('Драмы', '3'),
            ('Боевики', '17'),
            ('Приключения', '16'),
            ('Комедии', '21'),
            ('Триллеры', '4'),
            ('Фантастика', '12'),
            ('Мультфильмы', '18'),
            ('Криминал', '8'),
            ('Семейный', '10'),
            ('Фэнтези', '13'),
            ('Мелодрамы', '14'),
            ('Детектив', '25'),
            ('Ужасы', '7'),
            ('Исторический', '20'),
            ('Биография', '29'),
            ('Спорт', '5'),
            ('Военный', '23'),
            ('Мистика', '15'),
            ('Мюзикл', '9'),
            ('Вестерн', '19'),
            ('Аниме', '1'),
            ('Детский', '11'),
            ('Отечественные', '24'),
            ('Пародия', '30')
        ])

        for genre in genres:
            title = genre
            id   = genres[genre]

            items.append({'title':title, 'icon':'', 'id':id})
    except: pass

    return items
    
#method
def get_movieList(id, page = '1', refType = 'genre'):
    pagination_items = []
    items = []

    try:
        kg_stats(BASE_URL, GA_CODE, NK_CODE)

        result = common.fetchPage({'link': BASE_API_ML, 'post_data':{
            'ln'        : 'ru',
            'SESSION_ID': SESSIONID,
            'action'    : 'list',
            'refType'   : refType,
            'refId'     : id if refType == 'genre' else '',
            'currPage'  : page,
            'numPerPage': 50 if refType == 'genre' else 10,
            'orderByHow': '',
        }})
        if result['status'] == 200:
            data = json.loads( result['content'] )

            #======== pagination ========#
            pagination_items = KG_get_pagination(page, data['pages']['pagesCount'])
            #======== END pagination ========#


            for movie in data['list']:
                if not movie['category']:#Сериалы пока не нужны в выдаче по жанрам
                    #category = '[ ' + movie['category'] + ' ] ' if movie['category'] else ''
                    title = movie['title'].strip()
                    icon = BASE_URL + movie['imgPreview'][1:]
                    href  = movie['pagePath'][1:].decode('unicode_escape').encode('ascii','ignore')
                    id = movie['id']

                    items.append({'title':title, 'icon':icon, 'id':id, 'url':href})
    except: pass
    return {'items':items, 'pagination':pagination_items}


#method
def get_movie(url):
    items = []

    try:
        link = BASE_URL + url
        kg_stats(link, GA_CODE, NK_CODE)

        result = common.fetchPage({'link': link})
        if result['status'] == 200:
            html = result['content']
            page = common.parseDOM( html, 'div', attrs={'id': 'lp_padd'} )

            title = common.parseDOM(page, 'h1')[0]
            title_remove_span = title.index('<span')
            title = set_color('ПРОСМОТР: ', 'bold').decode('utf-8') + title[:title_remove_span]

            href = re.compile('path = \'(.+?)\';').findall(html)[0]
            icon = BASE_URL + common.parseDOM(page, 'img', attrs={'class':'moviebanner'}, ret='src')[0][1:]

            info = {}
            properties = {}
            # info  = {
            #     'duration'     : str2minutes(result_json['video']['duration']),
            #     'plot'         : result_json['video']['description'],
            # }
            # properties = {
            #     'fanart_image' : result_json['video']['big_preview'],
            # }
            

            items.append( {'title':title, 'icon':icon, 'url':href, 'info':info, 'properties':properties} )
    except: pass
    return items