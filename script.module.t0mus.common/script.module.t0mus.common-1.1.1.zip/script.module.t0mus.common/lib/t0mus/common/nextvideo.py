#!/usr/bin/python
# -*- coding: utf-8 -*-

#######################################
#                                     #
# script.module.t0mus.common for xbmc #
# author: t0mus                       #
#                                     #
#######################################

"""Url extractor for nextvideo host."""

import re
import urllib2
from BeautifulSoup import BeautifulSoup

def extract_urls(soup):
    """Return list of urls."""

    urls = []
    try:
        try:
            frame = soup.find('iframe',attrs={'src':re.compile('^http://nextvideo.pl/embed/')})
            link = frame['src']
            link2 = BeautifulSoup(urllib2.urlopen(link).read()).find('script').string.split('\'')[1]
            soup = BeautifulSoup(urllib2.urlopen(link2).read())
        except:
            pass

        for div in soup.find('div', id='mainVideo').findAll('script'):           
            content = div.string
            if content != None:
                clips = content.split('jwplayer("mediaplayer").setup')
                first = True
                for clip in clips:
                    if not first:
                        urls.append(clip.split('file: "')[1].split('"'
                                    )[0])
                    first = False
    except AttributeError:
        pass
    return urls


