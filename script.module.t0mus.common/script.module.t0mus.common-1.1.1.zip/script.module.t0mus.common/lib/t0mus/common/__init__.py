#!/usr/bin/python
# -*- coding: utf-8 -*-

__ALL__ = [
    'a33',
    'common',
    'hosting',
    'megustavid',
    'nextvideo',
    'putlocker',
    ]
