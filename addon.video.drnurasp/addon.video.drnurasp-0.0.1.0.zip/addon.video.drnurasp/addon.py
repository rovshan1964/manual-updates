#
#    Dette program er udviklet af Tim H. Nielsen
#    Der er fundet inspiration og taget udgangspunkt i et eksempel fra Tommy Winthers, videovideo, plugin.
#    Credits - http://tommy.winther.nu/wordpress/
#    2012 (C) - THN
#
#    This Program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2, or (at your option)
#    any later version.
#
#    This Program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this Program; see the file LICENSE.txt. If not, write to
#    the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#    http://www.gnu.org/copyleft/gpl.html
#
import xbmcgui
import sys
import xbmcplugin
import xbmcaddon
from urlparse import parse_qs, urlparse
import urllib2
from xml.dom import minidom

VIDEO_URL = 'http://www.dr.dk/nu/api/programseries.xml'
class LSTVHD(object):

  def showOverview(self):
    self._loadURL()
 
	
  def _loadURL(self):
    ICON = os.path.join(ADDON.getAddonInfo('path'), 'icon.png')
    FANART = os.path.join(ADDON.getAddonInfo('path'), 'fanart.jpg')
    #reading the file
    read_url = urllib2.urlopen(VIDEO_URL)
    xmldoc = minidom.parse(read_url)
	#gets the list - 0 gets the first element
    ArrayOfProgramSerie = xmldoc.getElementsByTagName("ArrayOfProgramSerie")[0]
    ProgramSeries = ArrayOfProgramSerie.getElementsByTagName("ProgramSerie")
    #print (ProgramSeries)
   # items = list()
    #try:
        #if ArrayOfProgramSerie is not None:
    for ProgramSerie in ProgramSeries:
        title = ProgramSerie.getElementsByTagName("Title")[0].firstChild.data.encode("utf-8")
               #content = entry.getElementsByTagName("content")[0].firstChild.data
                #print content
        published = ProgramSerie.getElementsByTagName("NewestVideoPublishTime")[0].firstChild.data.encode("utf-8")
        slug = ProgramSerie.getElementsByTagName("Slug")[0].firstChild.data.encode("utf-8")
        #description = ProgramSerie.getElementsByTagName("Description")[0].firstChild.data.encode("utf-8")
                #medias = entry.getElementsByTagName("media:group")
                #for media in medias:
        #thumbnail = media.getElementsByTagName("media:thumbnail")
        thumbnail_url = "http://www.dr.dk/nu/api/programseries/%s/images/50x50.jpg" % slug 
        video_id = ProgramSerie.getElementsByTagName("NewestVideoId")[0].firstChild.data.encode("utf-8")
       # print thumbnail_url
                    #duration = media.getElementsByTagName("yt:duration")
                   # duration_t =  duration[0].getAttribute('seconds')
                    #player = media.getElementsByTagName("media:player")
                    #player_data = player[0].getAttribute('url')
        item = xbmcgui.ListItem(title, iconImage = ICON, thumbnailImage = thumbnail_url  )
        infoLabels = {
            'title' : title,
            'plot' : "hest",
            'published' : published
            #'duration' : duration_t
        }
        VIDEO_PATH = "http://www.dr.dk/nu/api/videos/%s/" % video_id
        item.setInfo('video', infoLabels)
        item.setProperty("IsPlayable","true")
        item.setProperty('Fanart_Image', unicode(thumbnail_url))
                   # xbmc_dr_id =  parse_qs(urlparse(unicode(player_data)).query)['v'][0];
        #item.append((xbmc_url, item, False))
        xbmcplugin.addDirectoryItem(HANDLE, VIDEO_PATH, item, False)
       # xbmcplugin.addDirectoryItems(HANDLE,items)
    xbmcplugin.endOfDirectory(HANDLE)
  #  except Exception:
      #  self.message(ADDON.getLocalizedString(30900))
	
  def message(self, message):
    dialog = xbmcgui.Dialog()
    line1 = ADDON.getLocalizedString(99990)
    line2 = ADDON.getLocalizedString(99991)
    error = ADDON.getLocalizedString(99992)
    dialog.ok(message, line1, line2, error)
	
if __name__ == '__main__':
    ADDON = xbmcaddon.Addon(id = 'plugin.video.wondermentmc')
    PATH = 'plugin://plugin.video.youtube/?path=/root/search/new&action=play_video&videoid=%s'
    HANDLE = int(sys.argv[1])
	
    lstv = LSTVHD()
    lstv.showOverview()