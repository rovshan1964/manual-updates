#!/usr/bin/python
# -*- coding: utf-8 -*-

######################################
#                                    #
# plugin.video.filmy-a33-pl for xbmc #
# author: t0mus                      #
#                                    #
######################################

"""Strings for plugin.video.filmy-a33-pl."""

import os
import sys
import xbmc
import xbmcaddon

__addon__ = 'plugin.video.filmy-a33-pl'
__settings__ = xbmcaddon.Addon(id=__addon__)

__string_dir__ = \
    xbmc.translatePath(os.path.join(__settings__.getAddonInfo('path'),
                       'resources'))
sys.path.append(__string_dir__)

__strings__ = __settings__.getLocalizedString

__header_string__ = 'filmy.a33.pl'
__categories_string__ = __strings__(30000)
__search_string__ = __strings__(30001)
__nextpage_string__ = __strings__(30002)
__movietitle_string__ = __strings__(30003)
__loadingmovies_string__ = __strings__(30004)
__loadingcategories_string__ = __strings__(30005)
__networkerror_string__ = __strings__(30006)
