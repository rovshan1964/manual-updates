"""
    CrunchyRollxbmc
"""
import sys
import xbmcaddon

#plugin constants
__plugin__ = "Crunchyrollxbmc"
__version__ = "0.9.10.12"
__XBMCBUILD__ = xbmc.getInfoLabel( "System.BuildVersion" )
__settings__ = xbmcaddon.Addon(id='plugin.video.crunchyroll-takeout')

print "[PLUGIN] '%s: version %s' initialized!" % (__plugin__, __version__)

if __name__ == "__main__":
    from resources.lib import crunchy_main as crunchyrollxbmc
    if not sys.argv[2]:
        crunchyrollxbmc.Main()
    else:
        crunchyrollxbmc.Main()

sys.modules.clear()
