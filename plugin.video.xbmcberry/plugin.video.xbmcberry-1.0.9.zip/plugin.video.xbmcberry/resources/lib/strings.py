#!/usr/bin/python
# -*- coding: utf-8 -*-

####################################
#                                  #
# plugin.video.xbmcberry for xbmc  #
# author: t0mus                    #
#                                  #
####################################

"""Strings for plugin.video.xbmcberry."""

import os
import sys
import xbmc
import xbmcaddon

__addon__ = 'plugin.video.xbmcberry'
__settings__ = xbmcaddon.Addon(id=__addon__)

__string_dir__ = \
    xbmc.translatePath(os.path.join(__settings__.getAddonInfo('path'),
                       'resources'))
sys.path.append(__string_dir__)

__strings__ = __settings__.getLocalizedString

__header_string__ = 'xbmcberry'

