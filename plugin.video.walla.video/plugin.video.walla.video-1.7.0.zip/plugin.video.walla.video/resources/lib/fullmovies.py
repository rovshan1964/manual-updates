import urllib,urllib2,re,xbmcplugin,xbmcgui,os,time,sys
import plugin_helper

class FullmoviesManager:
  
  def __init__(self):
    self.MODES=plugin_helper.enum(GET_CATEGORY_LIST=1,GET_MOVIES_LIST=2,PLAY=3)
  
  def work(self,mode,url='',name=''):
    if (mode==self.MODES.GET_CATEGORY_LIST):
      self.getCategoryList()
    elif(mode==self.MODES.GET_MOVIES_LIST):
      self.getMoviesList(url,name)
    elif(mode==self.MODES.PLAY):
      plugin_helper.playRtmpFromUrl(url)
      
  def getCategoryList(self):
    categories = [('סרטים מלאים - דרמות',7373),('סרטים מלאים - קומדיות',7396),('סרטים מלאים – אקשן ואימה',7397),('סרטים מלאים - מצוירים',7367)]
    for name,url in categories:
      plugin_helper.addDir('Fullmovies',name,str(url),2,{"Title": urllib.unquote(name)},"DefaultFolder.png")
    
  def getMoviesList(self,url,name):
    matches  = self.getFromAjax('http://yes.walla.co.il/?w=1/'+url)
    for thumb,href,name,tagline in matches:
      plugin_helper.addVideo('Fullmovies',name,tagline,'http://yes.walla.co.il/'+href,3,{ "Title": urllib.unquote(name),"Tagline":urllib.unquote(tagline)},thumb)
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    
    
  
  def getFromAjax(self,url):
    match=[]
    length = 1
    i=0
    while (length>0 and i<=10):
        news = plugin_helper.getMatches(url+"/"+str(i)+"/10/@ajaxItems",'class="wtable wbgpos" background="(.*?)"><tr><Td class="picBorder \w+"><a href="(.*?)"><img src=http://iscWBE.walla.co.il/spc.gif width=80 height=60></a></td></tr></table>\n	</div>\n	<div style="float:right;padding:8 0 7 6;width:305" valign="top"><a href=".*?" class="w2b">(.*?)</a><br>(.*?)</div>')
        length=len(news)
        match+=news
        i+=1
    print(len(match))
    return match
