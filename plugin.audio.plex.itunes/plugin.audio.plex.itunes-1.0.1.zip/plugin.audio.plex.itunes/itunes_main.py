import os
import re
import sys
import urllib
import urllib2
import xbmc
import xbmcgui
import xbmcplugin
from BeautifulSoup import BeautifulSoup


class updateArgs:

	def __init__(self, *args, **kwargs):
		for key, value in kwargs.iteritems():
			if value == 'None':
				kwargs[key] = None
			else:
				kwargs[key] = urllib.unquote_plus(kwargs[key])
		self.__dict__.update(kwargs)


class UI:
	def __init__(self):
		xbmcplugin.setContent(int(sys.argv[1]), 'songs')
		self.parseArgs()

	def parseArgs(self):
		if (sys.argv[2]):
			exec "self.args = updateArgs(%s')" % (sys.argv[2][1:].replace('&', "',").replace('=', "='"))
		else:
			self.args = updateArgs(mode = 'None', url = 'None', name = 'None')
		
	def endofdirectory(self, sortMethod = 'none'):

		if sortMethod == 'title':
			xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)
			xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_RATING)
		elif sortMethod == 'none':
			xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_NONE)

		dontAddToHierarchy = False
		xbmcplugin.endOfDirectory(handle = int(sys.argv[1]), updateListing = dontAddToHierarchy)
		
	def addItem(self, info, songInfo, isFolder=True, total_items = 0):

		info.setdefault('name', 'None')
		info.setdefault('img', 'None')
		info.setdefault('url', 'None')
		info.setdefault('mode', 'None')
		
		if songInfo is None:
			u = sys.argv[0]+'?name='+urllib.quote_plus(info['name'])+'&img='+urllib.quote_plus(info['img'])+'&url='+urllib.quote_plus(info['url'])+'&mode='+urllib.quote_plus(info['mode'])
		else:
			u = sys.argv[0]+'?name='+urllib.quote_plus(info['name'])+'&img='+urllib.quote_plus(info['img'])+'&url='+urllib.quote_plus(info['url'])+'&mode='+urllib.quote_plus(info['mode'])+'&artist='+urllib.quote_plus(songInfo['artist'])+'&track='+urllib.quote_plus(songInfo['track'])+'&album='+urllib.quote_plus(songInfo['album'])
		
		li=xbmcgui.ListItem(label = info['name'], iconImage = info['img'], thumbnailImage = info['img'])
			
		if not isFolder:
			li.setInfo(type='Music', infoLabels = { 'Title': songInfo['track'], 'Artist': songInfo['artist'], 'Album': songInfo['album'] , 'url': info['url']})
			li.setProperty("mimetype", 'audio/mpeg')
			li.setProperty("IsPlayable", "true")
			contextmenu = [('Queue Song', 'Action(Queue)')]
		else:
			li.setProperty("IsPlayable", "false")
			contextmenu = []

		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=li, isFolder=isFolder, totalItems=total_items)


class Main:
	def __init__(self, checkMode = True):
		self.settings = sys.modules[ "__main__" ].__settings__
		self.parseArgs()
		self.address = self.settings.getSetting('ipaddress')
		self.port = 32400
		if self.address is None:
			self.address = '127.0.0.1'
		self.fullAddress = 'http://' + self.address + ':' + str(self.port)
		self.currentUrl = self.args.url
		if self.currentUrl is None:
			self.currentUrl = self.fullAddress + '/music/iTunes'
		
		if checkMode:
			self.checkMode()
			
	def checkMode(self):
		mode = self.args.mode
		if mode is None:
			self.main()
		elif mode == 'songs':
			self.playSong(self.args.url)
		else:
			self.listDirectory(self.args.url)
			
	def main(self):
		self.listDirectory(self.currentUrl)
		
	def listDirectory(self, path):
		
		print "iTUNES :: PLEX MEDIA SERVER: --> OPENING " + str(path)
		
		items = []
		titleKey = ''
		contentDict = {'artists': 'artist', 'albums': 'album', 'songs': 'track', 'other': 'title'}
		request = urllib2.Request(path)
		htmlSource = urllib2.urlopen(request).read()
		soup = BeautifulSoup(htmlSource, convertEntities=BeautifulSoup.HTML_ENTITIES)
		container = soup.find('mediacontainer')	
		
		try:
			content = container['content']
		except:
			content = 'directory'
		
		if content == 'artists': 
			items = soup.findAll(None, attrs={'key': True})[1:-1]
		else:
			items = soup.findAll(None, attrs={'key': True})
			
		if content == 'songs':
			isFolder = False
		else:
			isFolder = True
		try:
			titleKey = contentDict[content]
		except:
			titleKey = contentDict['other']
			
		numOfItems = len(items)

		print "iTUNES :: PLEX MEDIA SERVER: --> FOUND "+str(numOfItems)+" ITEM(S) IN DIRECTORY"
		
		for i, item in enumerate(items):
			try:
				thumbnail = self.fullAddress + str(item['thumb'])
			except:
				thumbnail = 'None'
			try:
				songInfo = {'artist': unicode(item['artist']).encode('utf-8'), 'track': unicode(item['track']).encode('utf-8'), 'album': unicode(item['album']).encode('utf-8')}
			except:
				songInfo = None
			UI().addItem({'name':unicode(item[titleKey].replace('&apos;', '\'')).encode('utf-8'), 'url': str(self.currentUrl + "/" + str(item['key'])), 'img': thumbnail, 'mode': str(content)}, songInfo, isFolder, numOfItems)
		UI().endofdirectory()
		
	def parseArgs(self):
		if (sys.argv[2]):
			exec "self.args = updateArgs(%s')" % (sys.argv[2][1:].replace('&', "',").replace('=', "='"))
		else:
			self.args = updateArgs(mode = 'None', url = 'None', name = 'None')
		
	def playSong(self, url):
		listItem=xbmcgui.ListItem(path=url)
		listItem.setInfo(type='Music', infoLabels = { 'Title': self.args.track, 'Artist': self.args.artist, 'Album': self.args.album , 'url': url})
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listItem)

	

