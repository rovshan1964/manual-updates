import urllib,urllib2,re,sys,xbmcplugin,xbmcgui
import cookielib,os,string,cookielib,StringIO
import os,time,base64,logging
import xbmcaddon
import xbmc
import time

#stv=xbmcaddon.Addon(id='plugin.video.rentadrone')
#addonPath=stv.getAddonInfo('path')

siteUrl          = 'http://blog.livenewschat.tv/'
serverUrl        = 'http://blog.livenewschat.tv/playlists/server.json'

def STREAMS1():
        req = urllib2.Request(siteUrl)
        req.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)')
        response = urllib2.urlopen(req)
        resp=response.read()
        response.close()
        web=''.join(resp.splitlines()).replace('\t','').replace('\'','"').replace('&nbsp;','').replace('    ', '')
        #match=re.compile('<h3>Live News Chat Rooms</h3><ul>(.+?)</ul>').findall(web)
        match=re.compile('<div class="sub-navigation"><ul(.+?)</ul></div>').findall(web)
        match=re.compile('(.+?)<a href="(.+?)">(.+?)</a></li>').findall(match[0])
        for sp, link, title in match:
            print title + ' : ' + link
            addLink(title,link,111,'')
        return True

def STREAMS():
        addLink('RockinRoosters Political Chat','http://blog.livenewschat.tv/rockinroosters/',111,'')
        addLink('CSPAN 1','http://blog.livenewschat.tv/cspan-1/',111,'')
        addLink('CSPAN 2','http://blog.livenewschat.tv/cspan-2/',111,'')
        addLink('CSPAN 3','http://blog.livenewschat.tv/cspan-3/',111,'')
        addLink('Stock Traders Chat','http://blog.livenewschat.tv/stock-traders-chat/',111,'')
        addLink('World News London','http://blog.livenewschat.tv/world-newsroom/',111,'')
        addLink('The Situation Chatroom','http://blog.livenewschat.tv/situation-chatroom/',111,'')
        addLink('UK News Chat','http://blog.livenewschat.tv/uk-news/',111,'')
        addLink('International Room','http://blog.livenewschat.tv/international-room-chat/',111,'')
        addLink('Euronews','http://blog.livenewschat.tv/euronews-english-chat/',111,'')
        addLink('The Bombshell Chatroom','http://blog.livenewschat.tv/the-nancy-grace-room/',111,'')
        addLink('CBS Live Webstream','http://blog.livenewschat.tv/cbs-raw-webstream/',111,'')
        addLink('Al Jazeera Chat','http://blog.livenewschat.tv/al-jazeera-news-chat/',111,'')
        addLink('France 24','http://blog.livenewschat.tv/france-24-english-chat/',111,'')
        addLink('RT America','http://blog.livenewschat.tv/rt-america-chat/',111,'')
        addLink('Russia Today Global','http://blog.livenewschat.tv/rt-onair-live',111,'')
        addLink('NHK World','http://blog.livenewschat.tv/nhk-world/',111,'')
        addLink('UK Parliament','http://blog.livenewschat.tv/bbc-parliament/',111,'')
        addLink('DR Update Denmark','http://blog.livenewschat.tv/dr-update-denmark/',111,'')
        addLink('Pentagon Channel','http://blog.livenewschat.tv/pentagon-channel/',111,'')

def PLAYLINK(url,name):
        #print 'Play Stream'
        ok=True
        videoUrl = GET_VIDEO_URL(url)
        if videoUrl == None:
                d = xbmcgui.Dialog()
                d.ok('NO VIDEO FOUND','NO VIDEO FOUND')
                return False
        print videoUrl
        liz=xbmcgui.ListItem(name)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        xbmcPlayer = xbmc.Player()
        xbmcPlayer.play(videoUrl,liz)
        return ok

def GET_VIDEO_URL(url):
        try:
            req = urllib2.Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)')
            req.add_header('Referer', siteUrl)
            response = urllib2.urlopen(req)
            resp=response.read()
            response.close()
            web=''.join(resp.splitlines())
            p=re.compile('flashplayer\: "(.+?)"\,(.+?)file\: "(.+?)",(.+?)</script>')
            match=p.findall(web)
            server = 'rtmp://' + GET_SERVER(url) + '/edge'
            for flash,sp2,file,sp3 in match:
                url = server + ' playpath=' + file + ' live=true pageURL=' + url + ' swfUrl=' + flash
                return url
        except: pass

def GET_VIDEO_URL2(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)')
        req.add_header('Referer', siteUrl)
        response = urllib2.urlopen(req)
        resp=response.read()
        response.close()
        web=''.join(resp.splitlines())
        p=re.compile('flashplayer\: "(.+?)"\,(.+?)file\: "(.+?)",(.+?)</script>')
        match=p.findall(web)
        server = 'rtmp://' + GET_SERVER(url) + '/edge'
        for flash,sp2,file,sp3 in match:
            url = server + ' playpath=' + file + ' live=true pageURL=' + url + ' swfUrl=' + flash
            return url

def GET_SERVER(url):
        req = urllib2.Request(serverUrl)
        req.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)')
        req.add_header('Referer', url)
        response = urllib2.urlopen(req)
        resp=response.read()
        response.close()
        web=''.join(resp.splitlines())
        p=re.compile('best\"\:\"(.+?)\"\}')
        match=p.findall(web)
        return match[0]

def addLink(name,url,mode,iconimage):
        #print 'iconimage : ' + iconimage
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
        return ok

def unescape(url):
        htmlCodes = [
                ['&', '&amp;'],
                ['<', '&lt;'],
                ['>', '&gt;'],
                ['"', '&quot;'],
        ]
        for code in htmlCodes:
                url = url.replace(code[1], code[0])
        return url

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

params=get_params()
url=None
referer=None
name=None
mode=None
icon=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        referer=int(params["referer"])
except:
        pass

if mode==None or url==None or len(url)<1:
        STREAMS()

elif mode==111:
        PLAYLINK(url,name)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
