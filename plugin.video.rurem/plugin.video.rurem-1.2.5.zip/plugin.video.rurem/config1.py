import sys
epgService      = '/ds/epg/service.asmx'
server          = 'ivsmedia.iptv-distribution.net'
ContentService  = '/ContentService.svc/soap'
sid             = '/ClientService.svc/soap'
siteId          = '5'
appName         = 'XBMC Plugin (' + sys.platform + ')'
streamService   = '/ds/cas/streams/generic/stream.asmx'
protocol        = 'mms'
vodService      = '/ucas/service.asmx'
vod2Service     = '/ds/vod/generic/service.asmx'
radioService    = '/ucas/service.asmx'


