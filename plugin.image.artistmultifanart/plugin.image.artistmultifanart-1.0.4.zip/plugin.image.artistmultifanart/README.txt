
How to use this addon in your skin:

Add a multiimage conrol:
<control type="multiimage">
..
<imagepath background="true">plugin://plugin.image.artistmultifanart/?name=$INFO[MusicPlayer.Title]</imagepath>
..
</control>


